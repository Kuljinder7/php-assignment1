<!doctype html>
<html lang="en">
    <head>
        <title>Employee information</title>
        <link rel="stylesheet" href="styles.css">
    </head>
    <body>
        <header>
        <div class="logo">Employee information</div>
        <nav>
        <li><a href="employeeform.php">Employee form</a></li>
                <li><a href="viewemployee.php">View Employee</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h1>Employees of company</h1>
        <form action="C:\xampp\htdocs\week4\employeeform.php" method="post">
            <label for="fname">first name</label>
            <input type="text" name="fname" id="fname"><br/>
            <label for="lname">Last Name</label>
            <input type="text" name="lname" id="lname"><br/>
            <label for="id">ID</label>
            <input type="text" name="id" id="id"><br/>
            <label for="hours_worked">Hours worked</br>
            <input type="number" name="hours_worked" id="hours_worked"></br>
            <label for="department">Department</label>
            <input type="text" name="department" id="department"></br>
            <button type="submit">SUBMIT</button>
        </form>

        <?php
        if($_SERVER['REQUEST_METHOD']='POST')
        {
            $fname=$_POST['fname'];
            $lname=$_POST['lname'];
             $id=$_POST['id'];
             $hours_worked=$_POST['hours_worked'] ;
             $department=$_POST['department'];
            //Database Connectivity
            $servername="localhost";
            $username="root";
            $password="";
            $database="employees";

            //creating a connection

            $conn=mysqli_connect($servername, $username, $password, $database);

            //die if connection failed
            if(!$conn)
            {
                die("Sorry, connection failed!!".mysqli_connect_error());
            }
            else
            {
                //submit the insertion queries/data to database
               $sql= "INSERT INTO `employees` (`fname`, `lname`, `ID`, `department`, `hours_worked`) VALUES (`fname`, `lname`, `ID`, `department`, `hours_worked`)";
                $result=mysqli_query($conn,$sql);

                if($result)
                {
                    echo "Data inserted successfully";

                }
                else{
                    echo "Data not inserted due to  ".mysqli_error($conn);
                }
            }

        }



        ?>
        </main>
        <footer>
        &copy; 2023 Your Company
    </footer>
    </body>
</html>



    